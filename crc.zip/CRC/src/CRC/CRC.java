package CRC;

import java.io.*;

public class CRC
{
public static void main(String s[])throws IOException
{
DataInputStream ds=new DataInputStream(System.in);
System.out.println("enter length of dataword");
int m=Integer.parseInt(ds.readLine());
int cnt=m;
System.out.println("enter length of divisor");
@SuppressWarnings("deprecation")
int n=Integer.parseInt(ds.readLine());
int no[],b[],a[];
no=new int[m+n];
b=new int[n];
System.out.println("enter the codeword");
for(int i=0;i<m;i++)
{
no[i]=Integer.parseInt(ds.readLine());
}
int count=n-1;
while(count!=0)
{
no[m++]=0;
count--;
}
System.out.println("enter the divisor");
for(int i=0;i<n;i++)
{
b[i]=Integer.parseInt(ds.readLine());
}
a=new int[m+n];
for(int i=0;i<n;i++)
{
a[i]=no[i];
}
int k=0;
int j;
while(k<cnt)
{
if(a[k]==1)
{
int x=0;
for(j=k;j<k+n;j++)
{
if (a[j]==b[x++])
a[j]=0;
else
a[j]=1;
}
}
else
{
for(j=k;j<k+n;j++)
{
if(a[j]==0)
a[j]=0;
else
a[j]=1;
}
}
a[j]=no[j];
k++;
}
System.out.println("the codeword is:");
for(int i=0;i<m-3;i++)
{
System.out.println(no[i]+" ");
}
for(int i=m-3;i<m;i++)
{
System.out.println(a[i]+" ");
}
}
}

